JEDI JCL/JVCL Installation

Supported development tools versions:

- Delphi 4 Update Pack #3 (JCL Only)
- Delphi 5 Update Pack #1
- Delphi 6 Update Pack #2 (including Personal Edition)
- Delphi 7

Please make sure you have installed latest update packs. You can download them
from Borland Support web page: http://www.borland.com/devsupport/delphi/

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! IMPORTANT !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! If you have installed any previous version of the JCL/JVCL you have to delete them. !
! It is also necessary to remove all installed JCL/JVCL packages from the IDE.      !
! Do not mix files or compiled packages from older versions of the JCL with    !
! current version.                                                             !
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

JEDI INSTALLER
==============

Helps you to integrate JCL/JVCL with Delphi IDE. Currently it assists with:

- Compiling and installing design-time packages to the IDE
- Adding sample JCL Debug extension dialogs to Object Repository
- Adding JCL and JVCL \Source path to Library Path in Environment Options
- Integrating JCL/JVCL help file to the IDE.


********************************************************
To start Installation click on: 
Install.bat 
file in the JEDI root folder.
********************************************************

NOTE:
======
We know of one case where there was a probelm when running install.bat:

Undeclared identifier: "TObjectList"
Unable to compile file: snmp.pas

The solution was to move the D7/D7.Net paths to the end of Environement Vars.

To do so, on NT/XP right-click My Computer,Properties,Advanced, Environment Variables, Find the PATH variable in the System variables list, click the Edit button and change the value (move D7 paths to the end).


